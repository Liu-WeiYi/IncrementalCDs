# coding: utf-8
import networkx as nx
import matplotlib.pyplot as plt

filename = "2004-04-20"

g = nx.Graph(name=filename)

with open(filename, "r+") as f:
    for line in f.readlines():
        src, dst = line.strip().split(" ")
        g.add_edge(src, dst)

# draw graph 
pos = nx.spring_layout(g)
nx.draw_networkx_nodes(g, pos, g.nodes(), node_size=800, node_color='w')
nx.draw_networkx_edges(g, pos, g.edges(), alpha=0.8)
nx.draw_networkx_labels(g, pos, font_size=16)

# plt.show()
nx.write_gexf(g,"gephi/%s.gexf"%filename)