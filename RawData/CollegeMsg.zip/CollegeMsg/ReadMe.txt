网址
http://snap.stanford.edu/data/CollegeMsg.html

Origin ReadMe:
This dataset is comprised of private messages sent on an online social network at the University of California, Irvine. 
Users could search the network for others and then initiate conversation based on profile information. 
An edge (u, v, t) means that user u sent a private message to user v at time t. 
The dataset here is derived from the one hosted by Tore Opsahl, 
    but we have parsed it so that it can be loaded directly into SNAP as a temporal network.

说明:
1. 该数据是加州大学Irvine分校的 在线社交网络的 私人邮件数据.
2. 该数据的作用是 如果当一个人想与另外一个人发起会话时，就会通过该社交网络。所以：
        2.1 Nodes: 网络的 节点 代表的是 人, 
        2.2 Edges: 网络的 边   代表的是 人和人之间发起的会话。比如人src通过搜索其他人的Profile information, 会找到想与之聊天的人dst.
                   那么就会形成 人src → 人dst 的一条"有向"边。 
3. 数据的形式: (u,v,t):
        3.1 u --- src
        3.2 v --- dst
        3.3 t --- 当前src 和 dst 之间产生连边时的时间戳(UNIX TimeStamp)

数据统计/Dataset statistics
Nodes	1899
Temporal Edges	59835
Edges in static graph	20296
Time span	193 days

数据分析:
1. 单一形式 --- 仅仅是人src发邮件给dst
20 21 1082444944 
--> 表示人20 在 时间1082444944 时联系了人21
--> 采用python中命令可以将UTC时间戳转换成当地时间:
    ------------------------------------------------------------------
    In [1]: import time
    In [2]: time.strftime('%Y-%m-%dT%H:%M:%S',time.gmtime(1082444944))
    ------------------------------------------------------------------
    Out[2]: '2004-04-20T07:09:04' (表示2004年4月20日 07点09分04秒)

2. 来回形式 --- 表示两个人之间的邮件往来
447 1866 1097044767
1866 447 1097044832
447 1866 1097044962
1866 447 1097045100

3. 在几个时间戳上都有相同的时间 --- 表示不同时间段下人src发邮件给人dst
447 1866 1097044767
447 1866 1097044962